const express = require('express');
const app = express();
const PORT = 3003;

app.use(express.json());

function loggerMiddleware(req, res, next) {
    const timestamp = new Date().toISOString();
    console.log(`[{timestamp}] ${req.method} ${req.url}`);
    next();
}

function authMiddleware(req, res, next) {
    const token = req.headers.authorizathion;

    if(!token || token !== 'Bearer meutoken123') {
        return res.status(401).json({error: 'Token Inválido'});
    }
    next();
}

app.use(loggerMiddleware);
app.get('/publico', (req, res) => {
    res.json({message: 'Esta rota é pública'});
});

app.get('/protegido', (req, res) => {
    res.json({message: 'É uma rota protegida'});
});

app.listen(PORT, () => {
    console.log(`Servidor com middleware rodando em http://localhost:${PORT}`);
});