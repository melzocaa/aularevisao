const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = 3005;

app.use(express.json()); 

app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.url}`);
  next();
});

function authMiddleware(req, res, next) {
  const token = req.headers.authorization;
  if (!token || token !== 'Bearer meutoken123') {
    return res.status(401).json({ erro: 'Token inválido' });
  }
  next();
}

let users = [];

app.post('/auth/register', (req, res) => {
  const { nome, email } = req.body;
  if (!nome || !email) return res.status(400).json({ erro: 'Nome e email são obrigatórios' });

  const novoUsuario = { id: users.length + 1, nome, email };
  users.push(novoUsuario);
  res.status(201).json(novoUsuario);
});

app.post('/auth/login', (req, res) => {
  res.json({ token: 'meutoken123' });
});

app.get('/users', authMiddleware, (req, res) => {
  res.json(users);
});

app.put('/users/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  const { nome, email } = req.body;
  const usuario = users.find(u => u.id == id);

  if (!usuario) return res.status(404).json({ erro: 'Usuário não encontrado' });

  usuario.nome = nome || usuario.nome;
  usuario.email = email || usuario.email;

  res.json(usuario);
});

app.delete('/users/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  users = users.filter(u => u.id != id);
  res.json({ mensagem: 'Usuário removido com sucesso' });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});

const upload = multer({ storage });

app.post('/upload', authMiddleware, upload.single('arquivo'), (req, res) => {
  res.json({ mensagem: 'Arquivo enviado com sucesso', arquivo: req.file });
});

app.get('/files', authMiddleware, (req, res) => {
  fs.readdir('uploads/', (err, files) => {
    if (err) return res.status(500).json({ erro: 'Erro ao listar arquivos' });
    res.json(files);
  });
});

app.get('/docs', (req, res) => {
  res.json({
    rotas: {
      '/auth/register': 'POST - cria usuário',
      '/auth/login': 'POST - retorna token',
      '/users': 'GET/PUT/DELETE - CRUD de usuários (precisa token)',
      '/upload': 'POST - upload de arquivo (precisa token)',
      '/files': 'GET - lista arquivos (precisa token)',
      '/docs': 'GET - documentação da API'
    }
  });
});

app.use((err, req, res, next) => {
  console.error('Erro no servidor:', err);
  res.status(500).json({ erro: 'Erro interno do servidor' });
});

app.listen(PORT, () => {
  console.log(`Projeto Final rodando em http://localhost:${PORT}`);
});
